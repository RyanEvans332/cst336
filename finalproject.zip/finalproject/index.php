<?php
session_start();

include 'inc/dbConnection.php';
$conn = getDatabaseConnection();

if(!isset($_SESSION['cart'])){//SET UP CART ARRAY
    $_SESSION['cart'] = array();
}

if(isset($_POST['email'])){//IF USER ENTERED THEIR EMAIL INTO NEWSLETTER
    $email = $_POST['email'];
}

if(isset($_POST['itemName'])){//ADD ITEM TO CART IF A POST REQUEST FOR THE ITEM WAS MADE
    
    //creating an array to hold an items properties
    $newItem = array();
    $newItem['name'] = $_POST['itemName'];
    $newItem['id'] = $_POST['itemId'];
    $newItem['price'] = $_POST['itemPrice'];
    $newItem['image'] = $_POST['itemImage'];
    
    foreach ($_SESSION['cart'] as &$item){
        if ($newItem['id'] == $item['id']){
            $item['quantity'] += 1;
            $found = true;
        }
    }
    
    //else add it to the array
    if ($found != true) {
        $newItem['quantity'] = 1;
      array_push($_SESSION['cart'], $newItem);  
    }
    
}

function displayCategories() {
    global $conn;
    
    $sql = "SELECT catId, catName FROM final_category ORDER BY catName";
    
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($records as $record) {
        echo "<option value='".$record["catId"]."'>" . $record["catName"] . "</option>";
    }     
}


function displaySearchResults(){
    global $conn;
    if(isset($_GET['searchForm'])){
        echo "<h3>Products Found: </h3>";
        //Query below prevents SQL injections
        $namedParameters = array();
        
        $sql = "SELECT * FROM final_product WHERE 1";

        if(!empty($_GET["product"])){
            $sql .= " AND (product_name LIKE :productName";
            $sql .= " OR product_description LIKE :productName)";
            $namedParameters[":productName"] = "%" . $_GET["product"] . "%";
        }
        
        if(!empty($_GET["category"])){
            $sql .= " AND catId = :categoryId";
            $namedParameters[":categoryId"] = $_GET["category"];
        }
        
        if(!empty($_GET["priceFrom"])){
            $sql .= " AND product_price >= :priceFrom";
            $namedParameters[":priceFrom"] = $_GET["priceFrom"];
        }
        
        if(!empty($_GET["priceTo"])){
            $sql .= " AND product_price <= :priceTo";
            $namedParameters[":priceTo"] = $_GET["priceTo"];
        }
        
        if(isset($_GET["orderBy"])){
            if($_GET["orderBy"] == "price"){
                $sql .= " ORDER BY product_price";
            } else {
                $sql .= " ORDER BY product_name";
            }
        }
 
        $stmt = $conn->prepare($sql);
        $stmt->execute($namedParameters);
        $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        foreach($records as $record){
           $itemImage = $record['product_image'];
           $itemName = $record['product_name'];
           $itemPrice = $record['product_price'];
           $itemId = $record['product_id'];
            //display item as table row
            echo '<tr>';
            echo "<td><img src='$itemImage' class='img-fluid'></td>";
            echo "<td><h4>$itemName</h4></td>";
            echo "<td><h4>$itemPrice</h4></td>";
            
            //Hidden input element containing the item name
            echo "<form method ='post'>";
            echo "<input type ='hidden' name = 'itemName' value ='$itemName'>";
            echo "<input type ='hidden' name = 'itemId' value ='$itemId'>";
            echo "<input type ='hidden' name = 'itemImage' value ='$itemImage'>";
            echo "<input type ='hidden' name = 'itemPrice' value ='$itemPrice'>";
            //check to see if the most recent post request has the same item id
            //if so this item was just added to the cart, display the different button
            if($_POST['itemId'] == $itemId){
             echo "<td><button class='btn btn-success'>Added</button></td>";   
            }else{
            echo "<td><button class='btn btn-warning'>Add</button></td>";
            }
            echo "</form>";
            
            echo "</tr>";
        }
    }
}




?>

<!DOCTYPE HTML>

    <head>
        <title>Black Friday Massacre!</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <style>
            @import url("css/styles.css");
        </style>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <link href="https://fonts.googleapis.com/css?family=Yellowtail" rel="stylesheet">
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
        <script type='text/javascript' src='js/functions.js'></script>
    </head>
   <body>
        
        
        
        
        
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
          <a class="navbar-brand" href="index.php">Black Friday Massacre!</a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="cart.php">Cart</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="login.php">Login</a>
              </li>
            </ul>
          </div>
        </nav>
        
        
      
        <div class="wrapper">
            <h1>Welcome to our shop!</h1>
            <h5>Please use the form below to search our inventory.</h5>
                <form class="form">
                    <table cellpadding="15" border = '1'>
                        <tr><td>Product:</td> <td><input class="form-control form-control-lg" type="text" name="product" /></td></tr>
                        
                        <tr><td>Category:</td> 
                            <td><select class="form-control" name="category">
                                <option value="">Select One</option>
                            <?=displayCategories()?>
                        </select></td></tr>
                        
                        <tr><td>Price:</td><td> 
                        
                        <div class="input-group mb-3">
                        <div class="input-group-prepend">
                        <span class="input-group-text">From $:</span></div>
                         <input type="text" name="priceFrom" size="1"/>
                        </div>
                        <div class="input-group mb-3">
                        <div class="input-group-prepend">
                        <span class="input-group-text">To $:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></div>
                        <input type="text" name="priceTo" size="1"/>
                        </div>
                        
                        
                        <tr><td>Order result by:</td>
                        
                        <td><input type="radio" name="orderBy" value="price"/> Price
                        <input type="radio" name="orderBy" value="name"/> Name </td></tr>
                      
                        <tr><td colspan='2'><input class="btn btn-primary" type="submit" value="Search" name="searchForm"/></td></tr>
                    </table>
                </form>
                
                <?=displaySearchResults()?>
                
                
                <br/><br/><br/><br/><br/><br/>
                
                
 
                <form method = "post" class="form" id="newsletter">
                    <span class="newslettertext">Newsletter</span><br/><br/>
                    If you feel so inclined, feel free to join our weekly newsletter!<br/><br/>
                    <div class="input-group mb-3">
                    <div class="input-group-prepend">
                    <span class="input-group-text">Email: &nbsp</span></div>
                    <input type="text" name="emailtext" id="emailtext" size="44"/>
                    </div>
                    <div id="rsp_email"></div>
                    <input class="btn btn-primary" type="submit" value="Sign me up!" name="newsletterbutton" id="newsletterbutton"/>
                </form>
        </div>
    </body>
</html>