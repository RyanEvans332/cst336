var emailVerificationStatus;
$(document).ready(function(){
  $("#emailtext").change(function(){
      var emailtext = $("#emailtext").val()
      
      $.ajax({
        url : "inc/validateEmail.php",
        type : "post",
        data : {emailtext:emailtext},
        
        success:function(response){
            emailVerificationStatus = response;
            //emailVerificationStatus of 1 means the email the user entered is completely invalid
            //emailVerificationStatus of 2 means the user entered a valid email that isnt in the database already
            //emailVerificationStatus of 3 means the user entered a valid email but it's already in our database
            
            if (emailVerificationStatus == 1){
                $("#rsp_email").css("color","red");
                $("#rsp_email").html("<b>This email is invalid.</b>");
            }
            if (emailVerificationStatus == 3){
                $("#rsp_email").css("color","red");
                $("#rsp_email").html("<b>You are already susbscribed!</b>");
            }
            if (emailVerificationStatus == 2){
                $("#rsp_email").css("color","green");
                $("#rsp_email").html("<b>This email is valid!</b>");
            }
        }
      })//ajax stuff
      
  })//emailtext being changed stuff
  
  
    $("#newsletter").on('submit', function(event){
        event.preventDefault();
        if($("#emailtext").val() == ''){//if the user hit submit with a blank form
            alert("You must enter a value into the email field!")
        }else{//if the user validly hits submit
            if(emailVerificationStatus == 2){
                var emailtext = $("#emailtext").val()
                $.ajax({
                    url : 'inc/emailToDatabase.php',
                    type : 'post',
                    data: {emailtext:emailtext},
                    
                    success:function(response){
                        if(response == 0){//if we successfully added the email to the database
                           $("#rsp_email").css("color","green");
                           $("#rsp_email").html("<b>You have been added to our newsletter!</b>"); 
                        }
                        else{//error adding to database
                            $("#rsp_email").css("color","black");
                            $("#rsp_email").html("Sorry, we had trouble adding your email to our list.");
                        }
                    }
                })//ajax stuff
            }
        }
    })//form submission stuff
})//document ready stuff