<?php
session_start();
include 'header.php'; //HEADER AND NAVI

function displayCheckout(){
    $subTotal = $_SESSION['subTotal'];
    $tax = $_SESSION['tax'];
    $shipping = $_SESSION['shipping'];
    $total = $_SESSION['total'];
    echo "<h3>Checkout:</h3>";
    echo "Subtotal: $".$subTotal; 
    echo "<br/>Tax: $".$tax;
    echo "<br/>Shipping: $".$shipping;
    echo "<br/><b>Total: $".$total."</b>";

    
}
?>
<div class ='wrapper'>
    </br>
    <div class = 'form'>
        <?=displayCheckout()?>
    </div>
</div>
