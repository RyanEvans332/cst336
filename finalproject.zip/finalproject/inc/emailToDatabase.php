<?php
//We've already fully validated the email in validateEmail.php
//This function will only be reached if we have a guaranteed valid email
//So we'll just simply add whatever ajax sent over via POST to the database
include 'dbConnection.php';
$conn = getDatabaseConnection();
$email = $_POST['emailtext'];
$sql = 'INSERT INTO final_subscriber (email) VALUES ("'.$email.'")';//We don't have to worry about sql injection since php validated the email in validateEmail.php
$stmt = $conn->prepare($sql);
$stmt->execute();

echo 0;//sent back to the ajax call to let it know everthing went okay
?>
