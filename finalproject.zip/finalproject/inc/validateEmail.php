<?php
//This file is used to verify that the email textbox in the subscriber newsletter is filled with a valid email address.

//emailVerificationStatus of 1 means the email the user entered is completely invalid
//emailVerificationStatus of 2 means the user entered a valid email that isnt in the database already
//emailVerificationStatus of 3 means the user entered a valid email but it's already in our database

$email = $_POST['emailtext'];
if (filter_var($email, FILTER_VALIDATE_EMAIL)){//If the email is valid, we'll make sure it's not already in the database
    include 'dbConnection.php';
    $conn = getDatabaseConnection();
    $sql = "SELECT count(*) as emailPresent FROM final_subscriber WHERE email = :email";
    $stmt = $conn->prepare($sql);
    $data = array(":email" => $email);
    $stmt->execute($data);
    $record = $stmt->fetch(PDO::FETCH_ASSOC);
    $count = $record['emailPresent'];
    if($count > 0){//then the email already exists in the database.
        $emailVerificationStatus = 3;
        echo 3;
    }else{//then the email isn't in the database and we can be sure it's okay to add it at form submission
        $emailVerificationStatus = 2;
        echo 2;
    }
}else{//IF EMAIL IS INVALID
    $emailVerificationStatus = 1;
    echo 1;
}
?>