<?php
session_start();
include 'inc/dbConnection.php';
$conn = getDatabaseConnection();
if(!isset($_SESSION['adminName'])){
    header("Location:login.php");
}

if(isset($_POST['email'])){
   $conn = getDatabaseConnection();
   $sql = "INSERT INTO final_subscriber (email) VALUES ('".$_POST['email']."')";
   $stmt = $conn->prepare($sql);
   $stmt->execute();
}

if(isset($_POST['removeId'])){
   $conn = getDatabaseConnection();
   $sql = "DELETE FROM final_subscriber WHERE subscriberId =".$_POST['removeId'];
   $stmt = $conn->prepare($sql);
   $stmt->execute();
}

if(isset($_POST['updateId'])){
 $conn = getDatabaseConnection();
  $sql = "UPDATE final_subscriber SET email = '".$_POST['updateEmail']."' WHERE subscriberId = ".$_POST['updateId'];
  $stmt = $conn->prepare($sql);
  $data = array(":email" => $_POST['updateEmail'], ":subscriberId" => $_POST['updateId']);
  $stmt->execute($data);
}

function getSubCount(){
  $conn = getDatabaseConnection();
  $sql = "SELECT count(*) as counter FROM final_subscriber";
  $stmt = $conn->prepare($sql);
  $stmt->execute();
  $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
  
  foreach($records as $record){
    echo $record['counter'];
  }
}

function generateNewsletterSubReport(){
  $conn = getDatabaseConnection();
  $sql = "SELECT * FROM final_subscriber";
  $stmt = $conn->prepare($sql);
  $stmt->execute();
  $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
  
  echo "<table cellpadding='5'><tr><td><b>Subscriber ID</b></td><td><b>Subscriber Email</td><td><!-- UPDATE BUTTON CELL--><td><!--REMOVE BUTTON CELL--></td></tr>";
  foreach($records as $record){
    echo "<form method='post'>";
    echo "<tr><td>".$record['subscriberId']."</td><td><input type ='text' name ='updateEmail' value ='".$record['email']."' size ='30'></td><td>";
    echo "<input type='hidden' name = 'updateId' value ='".$record['subscriberId']."'>";
    echo "<td><button class='btn btn-success'>Update Subscriber</button></td>";
    echo "</form>";
    echo "<form method='post'>";
    echo "<input type='hidden' name = 'removeId' value ='".$record['subscriberId']."'>";
    echo "<td><button class='btn btn-danger'>Remove subscriber</button></td>";
    echo "</form>";
  }
  echo "</table>";
  echo "<h4>Add a new Email</h4>";
  echo "<form method = 'post'>
        <input type = 'text' name = 'email'>
        <input type ='submit' class ='btn btn-success' value='Add!'>
        </form>";
}

function generateReport2() {
  $conn = getDatabaseConnection();
  $sql = "SELECT AVG(product_price) as price FROM final_product";
  $stmt = $conn->prepare($sql);
  $stmt->execute();
  $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
  
  foreach($records as $record){
    echo '$';
    echo round($record['price'], 2);
  }
}

function generateReport3(){
    $conn = getDatabaseConnection();
    $sql = "SELECT count(*) as number FROM final_product";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach($records as $record){
      echo $record['number'];
    }
}
?>

<!DOCTYPE HTML>
<html>
    <head>
        <title>Black Friday Massacre!</title>
        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <style>
            @import url("css/styles.css");
        </style>
        <link href="https://fonts.googleapis.com/css?family=Yellowtail" rel="stylesheet">
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    </head>
    <body>
        
        
        
        
        
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
          <a class="navbar-brand" href="index.php">Black Friday Massacre!</a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="cart.php">Cart</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="logout.php">Logout</a>
              </li>
            </ul>
          </div>
        </nav>
        
        
        
        
        
        <div class="wrapper"><br/>
                <div class="form">
                    <h6>Newsletter Subscriber report:</h6>
                    <?=generateNewsletterSubReport()?>
                    <b>Total Newsletter Subscriber Count: <?=getSubCount()?></b>
                </div>
                
                <form class="form">
                    <h6>Current Average Price of Products:</h6>
                    <?=generateReport2()?>
                </form>
                <form class="form">
                    <h6>Total Catalog of Products:</h6>
                    <?=generateReport3()?>
                </form>

        </div>
    </body>
</html>