<?php
session_start();
include 'header.php'; //HEADER AND NAVI
include 'inc/dbConnection.php';
$conn = getDatabaseConnection();
function displayCart(){
        if (isset($_SESSION['cart'])){
            $subTotal = 0;
            echo "<div class ='form'>";
            echo '<table cellpadding="5">';
            echo '<tr><td></td><td><b>Item name</b></td><td><b>Price</b></td><td><b>Quantity</b></td><td></td><td></td></tr>';
            foreach ($_SESSION['cart'] as $item){
                $itemName = $item['name'];
                $itemPrice = $item['price'];
                $itemImage = $item['image'];
                $itemId = $item['id'];
                $itemQuant = $item['quantity'];
                $subTotal += round($itemQuant * $itemPrice, 2);
                $tax = round($subTotal * .1, 2);
                $shipping = 5;
                $total = round($subTotal + $tax + $shipping, 2);
                $_SESSION['subTotal'] = $subTotal;
                $_SESSION['tax'] = $tax;
                $_SESSION['shipping'] = $shipping;
                $_SESSION['total'] = $total;
                //display item as table row
                echo "<tr>";
                echo "<td><img src='$itemImage' class='img-fluid'></td>";
                echo "<td><h6>$itemName</h6></td>";
                echo "<td><h6>$itemPrice</h6></td>";
                
                //update form for this item
                echo "<form method='post'>";
                echo "<input type='hidden' name ='itemId2' value ='$itemId'>";
                echo "<td><input type ='text' name ='update' class='form-control' placeHolder ='$itemQuant' size = '10'></td>";
                echo "<td><button class='btn btn-danger'>Update</button></td>";
                echo "</form>";
                
                
                //hidden input element containing the item name
                echo "<form method='post'>";
                echo "<input type='hidden' name = 'removeId' value ='$itemId'>";
                echo "<td><button class='btn btn-danger'>Remove</button></td>";
                echo "</form>";
                
                echo "</tr>";
                
            }
            echo '</table>';
            echo "</div>";
        echo '<form action="checkout.php">
        <input type="submit" class="button btn-success" value="Check out!" />
        </form>';
        }
    }
//if 'removeId' has been sent, search the cart for that item id then unset it
if (isset($_POST['removeId'])){
    foreach ($_SESSION['cart'] as $itemKey => $item){
        if ($item['id'] == $_POST['removeId']){
            unset($_SESSION['cart'][$itemKey]);
        }
    }
}
//if 'itemid2' quantity has been sent, search for the item with that id and update quantity
if(isset($_POST['itemId2'])){
    foreach ($_SESSION['cart'] as &$item){
        if ($item['id'] == $_POST['itemId2']){
            $item['quantity'] = $_POST['update'];
        }
    }
}
?>

<!DOCTYPE HTML>
<html>
    <!--see header.php--
    <head>
        <title>Black Friday Massacre!</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <style>
            @import url("css/styles.css");
        </style>
        <link href="https://fonts.googleapis.com/css?family=Yellowtail" rel="stylesheet">
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    </head>
    <body>
        
        
        
        
        
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
          <a class="navbar-brand" href="index.php">Black Friday Massacre!</a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="cart.php">Cart</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="login.php">Login</a>
              </li>
            </ul>
          </div>
        </nav>
    -->    
        
        
        
        
        <div class="wrapper"><br/>
         <?php
                if (isset($_SESSION['cart'])){
                    displayCart();
                }
        ?>
        </div>
    </body>
</html>